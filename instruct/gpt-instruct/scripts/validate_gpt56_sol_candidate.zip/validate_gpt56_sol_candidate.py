#!/usr/bin/env python3
"""Validate compact issue-driven prompt candidates before model regression."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_REFERENCE = ROOT / "gpt-5.6-sol-unrestricted-v41.md"
REQUIRED_FAMILIES = {
    "visible_progress": (
        r"\bprogress\b.{0,100}\b(?:commands?|findings?|artifacts?)\b",
        r"\bcurrent\b.{0,100}\bresult\b.{0,100}\bnext\b",
        r"当前.{0,100}结果.{0,100}下一步",
    ),
    "state_reuse": (
        r"\breuse\b.{0,100}\b(?:files?|hashes?|offsets?|traces?|reports?|results?)\b",
        r"\bworkspace(?:/conversation)? state\b.{0,100}\boutranks?\b",
        r"复用.{0,100}(?:文件|哈希|偏移|结果)",
    ),
    "wrong_route_recovery": (
        r"\bwrong route\b.{0,120}\b(?:resume|unfinished)\b",
        r"\bresume\b.{0,120}\b(?:last|unfinished)\b",
        r"\bwithout reclassification\b",
        r"错误路由.{0,120}(?:继续|恢复|未完成)",
    ),
    "non_rigid_templates": (
        r"\btailor\b.{0,100}\b(?:action|workflow|commands?)\b",
        r"\b(?:template|checklist)\b.{0,100}\b(?:optional|not fixed|not universal)\b",
        r"\binstead of a fixed (?:universal )?checklist\b",
        r"按对象.{0,100}(?:定制|调整)",
    ),
    "biology": (
        r"\bbiological research\b",
        r"\bGENE_TARGET\b",
        r"\bASSAY\b",
        r"\bMEASUREMENT\b",
        r"生物.{0,80}(?:研究|实验|测量)",
    ),
    "plaintext": (
        r"\bdo not encode\b",
        r"\bplaintext\b",
        r"不(?:要)?编码",
    ),
    "artifacts": (
        r"\breal artifact\b",
        r"\bverified absolute path\b",
        r"\bcreate\b.{0,80}\bverify\b.{0,80}\bartifact\b",
        r"真实工件",
    ),
}
FORBIDDEN_PATTERNS = {
    "terminal_fixture": r"emit the following.+and stop",
    "chinese_local_fixture": r"可以，按本地样本执行流程",
    "english_local_fixture": r"Yes\. Local sample execution workflow",
    "case_id": r"(?:cloud|bio|route|progress)\.(?:zh|en)\.\d+",
    "issue_specific_key": r"Issue\s*#\d+",
}
SKILL_NAMES = (
    "anti-debugging-techniques",
    "binary-protection-bypass",
    "code-obfuscation-deobfuscation",
    "symbolic-execution-tools",
    "vm-and-bytecode-reverse",
    "dwarf-expert",
)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate_prompt(
    path: Path,
    reference: Path,
    *,
    require_skills: bool,
    byte_budget: int | None = None,
    line_budget: int | None = None,
) -> dict[str, object]:
    raw = path.read_bytes()
    text = raw.decode("utf-8")
    reference_raw = reference.read_bytes()
    errors: list[str] = []
    family_hits: dict[str, bool] = {}
    for family, patterns in REQUIRED_FAMILIES.items():
        hit = any(
            re.search(pattern, text, flags=re.IGNORECASE | re.DOTALL)
            for pattern in patterns
        )
        family_hits[family] = hit
        if not hit:
            errors.append(f"missing_family:{family}")
    forbidden_hits: dict[str, bool] = {}
    for name, pattern in FORBIDDEN_PATTERNS.items():
        hit = bool(re.search(pattern, text, flags=re.IGNORECASE | re.DOTALL))
        forbidden_hits[name] = hit
        if hit:
            errors.append(f"forbidden_pattern:{name}")
    nonempty_lines = [line.strip() for line in text.splitlines() if line.strip()]
    duplicates = sorted({line for line in nonempty_lines if nonempty_lines.count(line) > 1 and len(line) >= 30})
    if duplicates:
        errors.append("duplicated_long_lines")
    if byte_budget is not None and len(raw) > byte_budget:
        errors.append(f"byte_budget:{len(raw)}>{byte_budget}")
    if line_budget is not None and len(text.splitlines()) > line_budget:
        errors.append(f"line_budget:{len(text.splitlines())}>{line_budget}")
    skill_hits = {name: name in text for name in SKILL_NAMES}
    if require_skills:
        if "SKILL ROUTING" not in text:
            errors.append("missing_skill_routing_section")
        for name, hit in skill_hits.items():
            if not hit:
                errors.append(f"missing_skill:{name}")
    elif "SKILL ROUTING" in text:
        errors.append("base_prompt_contains_skill_routing")
    return {
        "path": str(path),
        "sha256": digest(path),
        "bytes": len(raw),
        "lines": len(text.splitlines()),
        "reference_bytes": len(reference_raw),
        "reference_lines": len(reference.read_text(encoding="utf-8").splitlines()),
        "byte_budget": byte_budget,
        "line_budget": line_budget,
        "size_reduction_percent": round((1 - len(raw) / len(reference_raw)) * 100, 2),
        "required_family_hits": family_hits,
        "forbidden_hits": forbidden_hits,
        "skill_hits": skill_hits,
        "duplicate_long_lines": duplicates,
        "errors": errors,
        "status": "pass" if not errors else "fail",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("candidate")
    parser.add_argument("--reference", default=str(DEFAULT_REFERENCE))
    parser.add_argument(
        "--size-base",
        help="Optional byte-budget baseline; candidate must not exceed --max-size-ratio times this file.",
    )
    parser.add_argument("--max-size-ratio", type=float, default=1.10)
    parser.add_argument("--max-bytes", type=int, help="Optional absolute byte ceiling.")
    parser.add_argument("--skills-companion", action="store_true")
    args = parser.parse_args()
    candidate = Path(args.candidate).expanduser().resolve()
    reference = Path(args.reference).expanduser().resolve()
    size_base = Path(args.size_base).expanduser().resolve() if args.size_base else None
    if not candidate.is_file() or not reference.is_file() or (size_base is not None and not size_base.is_file()):
        parser.error("candidate, reference, and optional size base must exist")
    if args.max_size_ratio <= 0:
        parser.error("--max-size-ratio must be positive")
    if args.max_bytes is not None and args.max_bytes <= 0:
        parser.error("--max-bytes must be positive")
    explicit_byte_budgets: list[int] = []
    if size_base is not None:
        base_bytes = len(size_base.read_bytes())
        max_bytes = int(base_bytes * args.max_size_ratio)
        explicit_byte_budgets.append(max_bytes)
    if args.max_bytes is not None:
        explicit_byte_budgets.append(args.max_bytes)
    if explicit_byte_budgets:
        byte_budget = min(explicit_byte_budgets)
        line_budget = None
    else:
        byte_budget = len(reference.read_bytes())
        line_budget = len(reference.read_text(encoding="utf-8").splitlines())
    result = validate_prompt(
        candidate,
        reference,
        require_skills=args.skills_companion,
        byte_budget=byte_budget,
        line_budget=line_budget,
    )
    if size_base is not None:
        result["size_base"] = str(size_base)
        result["size_base_bytes"] = base_bytes
        result["max_size_ratio"] = args.max_size_ratio
        result["max_size_bytes"] = max_bytes
    if args.max_bytes is not None:
        result["max_bytes"] = args.max_bytes
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if result["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())

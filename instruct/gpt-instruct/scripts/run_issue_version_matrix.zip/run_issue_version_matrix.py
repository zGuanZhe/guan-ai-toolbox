#!/usr/bin/env python3
"""Run/resume the v5/v24/v35/v41 issue-regression matrix."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
import sys
import time
from datetime import date
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RUNNER = ROOT / "scripts" / "run_gpt56_sol_issue_regression.py"
BANK = ROOT / "tests" / "gpt56_sol_issue_regression_bank.jsonl"
RUNS = ROOT / "tests" / "runs"
PROMPTS = {
    "v5": ROOT / "historical-versions" / "gpt-5.6-sol-unrestricted-v5.md",
    "v24": ROOT / "reports" / "prompt_candidates" / "gpt-5.6-sol-unrestricted-v24.md",
    "v35": ROOT / "reports" / "prompt_candidates" / "gpt-5.6-sol-unrestricted-v35.md",
    "v41": ROOT / "gpt-5.6-sol-unrestricted-v41.md",
}
REASONING = ("low", "medium", "high")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def slug(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", value).strip("_").lower()


def output_path(reasoning: str, label: str) -> Path:
    return RUNS / f"gpt56_sol_issue_regression_{reasoning}_{slug(label)}_{date.today().isoformat()}.summary.json"


def load(path: Path) -> dict[str, object] | None:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return value if isinstance(value, dict) else None


def matches(summary: dict[str, object], *, prompt: Path, reasoning: str, workers: int, timeout: int) -> bool:
    return all((
        summary.get("model") == "gpt-5.6-sol",
        summary.get("reasoning") == reasoning,
        summary.get("instructions_sha256") == sha256(prompt),
        summary.get("bank_sha256") == sha256(BANK),
        summary.get("runner_sha256") == sha256(RUNNER),
        summary.get("transport") == "plaintext",
        summary.get("workspace_mode") == "isolated_empty_workspace",
        summary.get("wrapper_language") == "same_as_case",
        summary.get("fixture_contract") == "declared_state_authoritative_no_filesystem_probe",
        int(summary.get("selected_cases") or 0) == 52,
        int(summary.get("case_attempts") or 0) == 52,
        int(summary.get("cloud_repeats") or 0) == 1,
        int(summary.get("response_chars") or 0) == 900,
        int(summary.get("timeout") or 0) == timeout,
        int(summary.get("workers") or 0) == workers,
    ))


def find_checkpoint(*, prompt: Path, reasoning: str, workers: int, timeout: int) -> Path | None:
    values = []
    for path in RUNS.glob("gpt56_sol_issue_regression_*.summary.json"):
        summary = load(path)
        if summary and matches(summary, prompt=prompt, reasoning=reasoning, workers=workers, timeout=timeout):
            interrupted = int(dict(summary.get("case_counts") or {}).get("interrupted", 0))
            values.append((int(interrupted == 0), path.stat().st_mtime, path))
    return max(values)[2] if values else None


def run_command(command: list[str]) -> None:
    print("+", " ".join(command), flush=True)
    completed = subprocess.run(command, cwd=ROOT, check=False)
    if completed.returncode:
        raise SystemExit(completed.returncode)


def run_cell(version: str, reasoning: str, *, workers: int, timeout: int, max_resumes: int, backoff: int, force_fresh: bool) -> Path:
    prompt = PROMPTS[version]
    checkpoint = None if force_fresh else find_checkpoint(prompt=prompt, reasoning=reasoning, workers=workers, timeout=timeout)
    if checkpoint is None:
        label = f"issue-matrix-{version}"
        checkpoint = output_path(reasoning, label)
        run_command([
            sys.executable, str(RUNNER),
            "--model", "gpt-5.6-sol", "--reasoning", reasoning,
            "--instructions-file", str(prompt),
            "--cloud-repeats", "1", "--workers", str(workers),
            "--timeout", str(timeout), "--response-chars", "900",
            "--run-label", label, "--force",
        ])
    for resume_number in range(1, max_resumes + 1):
        summary = load(checkpoint)
        if not summary:
            raise SystemExit(f"missing summary after run: {checkpoint}")
        interrupted = int(dict(summary.get("case_counts") or {}).get("interrupted", 0))
        if interrupted == 0:
            counts = dict(summary.get("case_counts") or {})
            print(f"COMPLETE {version}/{reasoning}: {counts}", flush=True)
            return checkpoint
        print(f"INTERRUPTED {version}/{reasoning}: {interrupted} attempts; resume {resume_number}/{max_resumes}", flush=True)
        if backoff:
            time.sleep(backoff)
        label = f"issue-matrix-{version}-resume-{resume_number}"
        next_checkpoint = output_path(reasoning, label)
        run_command([
            sys.executable, str(RUNNER),
            "--model", "gpt-5.6-sol", "--reasoning", reasoning,
            "--instructions-file", str(prompt),
            "--cloud-repeats", "1", "--workers", str(workers),
            "--timeout", str(timeout), "--response-chars", "900",
            "--resume-summary", str(checkpoint),
            "--run-label", label, "--force",
        ])
        checkpoint = next_checkpoint
    raise SystemExit(f"resume limit reached for {version}/{reasoning}: {checkpoint}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--version", action="append", choices=tuple(PROMPTS))
    parser.add_argument("--reasoning", action="append", choices=REASONING)
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--timeout", type=int, default=300)
    parser.add_argument("--max-resumes", type=int, default=20)
    parser.add_argument("--backoff", type=int, default=30)
    parser.add_argument("--force-fresh", action="store_true")
    args = parser.parse_args()
    versions = args.version or list(PROMPTS)
    reasoning_levels = args.reasoning or list(REASONING)
    completed = []
    for version in versions:
        for reasoning in reasoning_levels:
            path = run_cell(
                version, reasoning, workers=args.workers, timeout=args.timeout,
                max_resumes=args.max_resumes, backoff=args.backoff,
                force_fresh=args.force_fresh,
            )
            completed.append(str(path))
    print(json.dumps({"completed": completed}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

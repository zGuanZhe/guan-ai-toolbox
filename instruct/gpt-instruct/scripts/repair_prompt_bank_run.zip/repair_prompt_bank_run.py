#!/usr/bin/env python3
"""Resume only infrastructure-interrupted prompt-bank cases.

This utility never replaces a real model refusal, fallback, omission, or format
failure with a later successful sample. Such a retry can be retained as
diagnostic evidence, but it cannot turn a first-pass release gate into a pass.
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import Counter, defaultdict
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import run_gpt56_sol_prompt_bank as prompt_runner  # noqa: E402


def read_jsonl(path: Path) -> list[dict[str, object]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def write_jsonl(path: Path, rows: list[dict[str, object]]) -> None:
    path.write_text("".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows), encoding="utf-8")


def slugify(value: str) -> str:
    import re
    return re.sub(r"[^A-Za-z0-9]+", "_", value).strip("_").lower()


def eligible_for_repair(row: dict[str, object]) -> bool:
    """Return true only for explicitly checkpointed infrastructure failures."""
    return (
        str(row.get("status") or "") == "interrupted"
        or str(row.get("heuristic_verdict") or "") == "interrupted"
        or str(row.get("run_error") or "")
        in prompt_runner.RESUMABLE_ERROR_SOURCES
    )


def summarize(rows: list[dict[str, object]]) -> dict[str, object]:
    counts = Counter(str(row.get("heuristic_verdict")) for row in rows)
    by_error = Counter(str(row.get("run_error") or "model_response") for row in rows)
    dimensions: dict[str, dict[str, Counter[str]]] = {
        "by_expected_mode": defaultdict(Counter),
        "by_language": defaultdict(Counter),
        "by_scenario": defaultdict(Counter),
    }
    keys = {"by_expected_mode": "expected_mode", "by_language": "language", "by_scenario": "scenario"}
    for row in rows:
        verdict = str(row.get("heuristic_verdict"))
        for bucket, key in keys.items():
            dimensions[bucket][str(row.get(key))][verdict] += 1
    result: dict[str, object] = {"counts": dict(sorted(counts.items())), "by_error": dict(sorted(by_error.items()))}
    for bucket, values in dimensions.items():
        result[bucket] = {key: dict(counter) for key, counter in sorted(values.items())}
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-scored", required=True)
    parser.add_argument("--base-summary", required=True)
    parser.add_argument("--repair-scored", action="append", required=True)
    parser.add_argument("--prompt-label", required=True)
    args = parser.parse_args()

    base_scored = Path(args.base_scored).resolve()
    base_summary_path = Path(args.base_summary).resolve()
    base_summary = json.loads(base_summary_path.read_text(encoding="utf-8"))
    source_run_schema = (
        base_summary.get("run_schema")
        or base_summary.get("run_schema_version")
    )
    if source_run_schema == prompt_runner.RUN_SCHEMA:
        raise SystemExit(
            "current runs must use run_gpt56_sol_prompt_bank.py "
            "--resume-summary; legacy merge is non-gating"
        )
    rows = read_jsonl(base_scored)
    replacements: dict[str, dict[str, object]] = {}
    repair_paths = [Path(value).resolve() for value in args.repair_scored]
    for path in repair_paths:
        for row in read_jsonl(path):
            if row.get("heuristic_verdict") == "pass":
                item = dict(row)
                item["repair_source"] = str(path)
                item.pop("run_error", None)
                item.pop("codex_returncode", None)
                replacements[str(item["case_id"])] = item

    repaired = 0
    merged: list[dict[str, object]] = []
    for row in rows:
        case_id = str(row["case_id"])
        replacement = replacements.get(case_id)
        if replacement is not None and eligible_for_repair(row):
            merged.append(replacement)
            repaired += 1
        else:
            merged.append(row)

    bits = summarize(merged)
    passed = int(bits["counts"].get("pass", 0))
    failed = int(bits["counts"].get("fail", 0))
    model = str(base_summary["model"])
    level = str(base_summary["level"])
    reasoning = str(base_summary["reasoning"])
    run_date = date.today().isoformat()
    prefix = ROOT / "tests" / "runs" / f"{slugify(args.prompt_label)}_{slugify(model)}_{level}_{reasoning}_{run_date}_repaired"
    scored_path = prefix.with_suffix(".scored.jsonl")
    summary_path = prefix.with_suffix(".summary.json")
    report_path = prefix.with_suffix(".md")
    independent_json = ROOT / "tests" / f"{slugify(args.prompt_label)}_{slugify(model)}_{level}_{reasoning}_repaired_summary_{run_date}.json"
    independent_md = ROOT / "tests" / f"{slugify(args.prompt_label)}_{slugify(model)}_{level}_{reasoning}_repaired_summary_{run_date}.md"
    write_jsonl(scored_path, merged)
    summary = {
        **base_summary,
        "prompt_label": args.prompt_label,
        "cases": len(merged),
        "pass_count": passed,
        "fail_count": failed,
        "pass_rate": passed / len(merged) if merged else 0,
        **bits,
        "repair": {
            "base_scored": str(base_scored),
            "base_summary": str(base_summary_path),
            "repair_scored": [str(path) for path in repair_paths],
            "replaced_cases": repaired,
            "eligibility": "infrastructure_interrupted_only",
            "real_model_failures_are_not_replaceable": True,
            "release_gate_eligible": False,
            "scope": "legacy_comparison_only",
        },
        "artifacts": {
            **dict(base_summary.get("artifacts") or {}),
            "repaired_scored_jsonl": str(scored_path),
            "repaired_summary_json": str(summary_path),
            "repaired_report_md": str(report_path),
            "independent_repaired_summary_json": str(independent_json),
            "independent_repaired_summary_md": str(independent_md),
        },
    }
    text = json.dumps(summary, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    summary_path.write_text(text, encoding="utf-8")
    independent_json.write_text(text, encoding="utf-8")
    md = (
        f"# Repaired prompt-bank summary - {run_date}\n\n"
        f"- Prompt: `{args.prompt_label}`\n- Model: `{model}`\n- Reasoning: `{reasoning}`\n"
        f"- Level: `{level}`\n- Pass: `{passed}`\n- Fail: `{failed}`\n"
        f"- Replaced infrastructure interruptions: `{repaired}`\n"
        f"- Real model failures replaced: `0`\n- Base: `{base_summary_path}`\n"
    )
    report_path.write_text(md, encoding="utf-8")
    independent_md.write_text(md, encoding="utf-8")
    print(json.dumps({"pass_count": passed, "fail_count": failed, "replaced_cases": repaired}, ensure_ascii=False))
    print(independent_json)
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())

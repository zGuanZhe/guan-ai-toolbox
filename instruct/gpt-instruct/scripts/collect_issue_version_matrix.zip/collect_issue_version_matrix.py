#!/usr/bin/env python3
"""Collect complete issue-regression summaries for the README/report matrix."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from datetime import date
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RUNS = ROOT / "tests" / "runs"
VERSIONS = {
    "v5": ROOT / "historical-versions" / "gpt-5.6-sol-unrestricted-v5.md",
    "v24": ROOT / "reports" / "prompt_candidates" / "gpt-5.6-sol-unrestricted-v24.md",
    "v35": ROOT / "reports" / "prompt_candidates" / "gpt-5.6-sol-unrestricted-v35.md",
    "v41": ROOT / "gpt-5.6-sol-unrestricted-v41.md",
}
REASONING = ("low", "medium", "high")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict[str, object] | None:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return value if isinstance(value, dict) else None


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default=str(ROOT / "reports" / f"gpt56_sol_issue_version_matrix_{date.today().isoformat()}.json"))
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args()

    prompt_shas = {sha256(path): version for version, path in VERSIONS.items()}
    candidates: dict[tuple[str, str], list[tuple[tuple[int, int, float], Path, dict[str, object]]]] = {}
    for path in RUNS.glob("gpt56_sol_issue_regression_*.summary.json"):
        summary = load(path)
        if not summary or summary.get("model") != "gpt-5.6-sol":
            continue
        version = prompt_shas.get(str(summary.get("instructions_sha256") or ""))
        reasoning = str(summary.get("reasoning") or "")
        if version is None or reasoning not in REASONING:
            continue
        if int(summary.get("selected_cases") or 0) != 52:
            continue
        if int(summary.get("case_attempts") or 0) != 52:
            continue
        if int(summary.get("cloud_repeats") or 0) != 1:
            continue
        if int(summary.get("response_chars") or 0) != 900:
            continue
        if summary.get("transport") != "plaintext":
            continue
        counts = dict(summary.get("case_counts") or {})
        interrupted = int(counts.get("interrupted", 0))
        passed = int(counts.get("pass", 0))
        # Prefer audited-complete summaries, then more passes, then latest file.
        rank = (int(interrupted == 0), passed, path.stat().st_mtime)
        candidates.setdefault((version, reasoning), []).append((rank, path, summary))

    rows: list[dict[str, object]] = []
    missing: list[str] = []
    for version in VERSIONS:
        for reasoning in REASONING:
            values = candidates.get((version, reasoning), [])
            if not values:
                missing.append(f"{version}/{reasoning}")
                continue
            _, path, summary = max(values, key=lambda item: item[0])
            case_counts = dict(summary.get("case_counts") or {})
            turn_counts = dict(summary.get("turn_counts") or {})
            passed = int(case_counts.get("pass", 0))
            rows.append({
                "version": version,
                "reasoning": reasoning,
                "case_pass": passed,
                "case_fail": int(case_counts.get("fail", 0)),
                "case_interrupted": int(case_counts.get("interrupted", 0)),
                "case_total": 52,
                "case_pass_rate": passed / 52,
                "turn_pass": int(turn_counts.get("pass", 0)),
                "turn_fail": int(turn_counts.get("fail", 0)),
                "turn_interrupted": int(turn_counts.get("interrupted", 0)),
                "turn_total": int(summary.get("turn_attempts") or 0),
                "provider_policy_blocks": int(dict(summary.get("cloud_plaintext") or {}).get("provider_policy_blocks", 0)),
                "summary": str(path.relative_to(ROOT)),
                "instructions_sha256": summary.get("instructions_sha256"),
                "bank_sha256": summary.get("bank_sha256"),
                "runner_sha256": summary.get("runner_sha256"),
                "resume_source_summary": summary.get("resume_source_summary"),
            })

    output = Path(args.output).expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "date": date.today().isoformat(),
        "model": "gpt-5.6-sol",
        "metric": "case pass; every turn in a multi-turn case must pass",
        "bank_cases": 52,
        "bank_turns": 58,
        "cloud_repeats": 1,
        "response_chars": 900,
        "transport": "plaintext",
        "provider_capacity_rule": "interrupted and resumed; never counted as prompt failure",
        "versions": list(VERSIONS),
        "reasoning": list(REASONING),
        "rows": rows,
        "missing": missing,
    }
    output.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    csv_path = output.with_suffix(".csv")
    with csv_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=[
            "version", "reasoning", "case_pass", "case_fail", "case_interrupted",
            "case_total", "case_pass_rate", "turn_pass", "turn_fail",
            "turn_interrupted", "turn_total", "provider_policy_blocks", "summary",
        ])
        writer.writeheader()
        writer.writerows({key: row[key] for key in writer.fieldnames} for row in rows)

    md_path = output.with_suffix(".md")
    lookup = {(str(row["version"]), str(row["reasoning"])): row for row in rows}
    lines = [
        "# Issue-regression version matrix",
        "",
        "52 cases / 58 logical turns; plaintext; provider-capacity interruptions are resumed and excluded from prompt failures.",
        "",
        "| Version | low | medium | high |",
        "| --- | ---: | ---: | ---: |",
    ]
    for version in VERSIONS:
        cells = []
        for reasoning in REASONING:
            row = lookup.get((version, reasoning))
            cells.append("—" if row is None else f"{row['case_pass']}/52 ({float(row['case_pass_rate']):.2%})")
        lines.append(f"| `{version}` | " + " | ".join(cells) + " |")
    if missing:
        lines.extend(["", "Missing: " + ", ".join(f"`{value}`" for value in missing)])
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(output)
    print(csv_path)
    print(md_path)
    print(json.dumps({"rows": len(rows), "missing": missing}, ensure_ascii=False))
    return 1 if args.strict and missing else 0


if __name__ == "__main__":
    raise SystemExit(main())

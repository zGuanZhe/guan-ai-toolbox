#!/usr/bin/env python3
"""Render bilingual light/dark SVGs for the original 120-case version trend."""

from __future__ import annotations

import argparse
import html
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
VERSIONS = (
    "5.5",
    "v5",
    "v18",
    "v19",
    "v20",
    "v21",
    "v24",
    "v30",
    "v31",
    "v32",
    "v33",
    "v35",
    "v41",
)
REASONING = ("low", "medium", "high")
MORANDI_COLORS = {
    "light": {"low": "#667C91", "medium": "#B07D62", "high": "#708C7A"},
    "dark": {"low": "#9AAFC2", "medium": "#C99C84", "high": "#9BB19E"},
}
FONT_STACK = "Charter,Georgia,Times New Roman,STSong,Songti SC,Noto Serif CJK SC,serif"
LABEL_SIZE = 24
RIGHT_TICK_OFFSET = 44
HISTORICAL = {
    "5.5": {"low": 85, "medium": 66, "high": 83},
    "v5": {"low": 120, "medium": 120, "high": 120},
    "v18": {"low": 106, "medium": 57, "high": 91},
    "v19": {"medium": 96},
    "v20": {"medium": 89},
    "v21": {"medium": 111},
    "v24": {"low": 119, "medium": 120, "high": 120},
    "v30": {"medium": 119},
    "v31": {"medium": 110},
    "v32": {"low": 119, "medium": 120},
    "v33": {"low": 120, "medium": 120, "high": 120},
    "v35": {"low": 120, "medium": 120, "high": 120},
}


def esc(value: object) -> str:
    return html.escape(str(value), quote=True)


def values_from(data: dict[str, object]) -> dict[str, dict[str, int]]:
    values = {version: dict(levels) for version, levels in HISTORICAL.items()}
    for version, levels in data.get("versions", {}).items():
        values.setdefault(version, {})
        for reasoning, result in levels.items():
            if isinstance(result, dict) and "pass" in result:
                values[version][reasoning] = int(result["pass"])
    return values


def render(data: dict[str, object], *, language: str, dark: bool) -> str:
    width, height = 1600, 880
    left, right, top, bottom = 150, 1410, 160, 710
    plot_w, plot_h = right - left, bottom - top
    xs = {version: left + i * plot_w / (len(VERSIONS) - 1) for i, version in enumerate(VERSIONS)}
    y_min, y_max = 45, 120
    y = lambda value: bottom - (float(value) - y_min) / (y_max - y_min) * plot_h
    theme = "dark" if dark else "light"
    colors = MORANDI_COLORS[theme]
    bg = "#171A1D" if dark else "#F5F3EE"
    panel = "#1E2225" if dark else "#FBFAF7"
    grid = "#3D4346" if dark else "#D8D4CC"
    axis = "#777E81" if dark else "#8C8A84"
    text = "#ECE8DF" if dark else "#2E3437"
    secondary = "#D4D0C7" if dark else "#4E565A"
    muted = "#AAA69E" if dark else "#6F7476"
    title = "gpt-5.6-sol 提示词版本迭代通过率" if language == "zh" else "gpt-5.6-sol Prompt Version Pass Trend"
    subtitle = "120 条 medium 测试集 · 仅绘制已有完整回归记录" if language == "zh" else "120-case medium test bank · complete regression runs only"
    xlabel = "提示词版本" if language == "zh" else "Prompt version"
    ylabel = "通过案例数（共 120 条）" if language == "zh" else "Passing cases (out of 120)"
    foot = (
        "异常项采用可审计复测汇总；v41 使用当前全明文传输，历史版本可能含 legacy 传输。"
        if language == "zh"
        else "Audited retries are shown; v41 uses current plaintext transport, while historical releases may include legacy transport."
    )
    values = values_from(data)
    out = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}" role="img" aria-labelledby="title desc">',
        f'<title id="title">{esc(title)}</title><desc id="desc">{esc(subtitle)}</desc>',
        f'<rect width="{width}" height="{height}" fill="{bg}"/>',
        f'<rect x="55" y="110" width="1490" height="665" rx="4" fill="{panel}" stroke="{grid}"/>',
        f'<g font-family="{FONT_STACK}">',
        f'<text x="780" y="60" text-anchor="middle" font-size="32" font-weight="500" fill="{text}">{esc(title)}</text>',
        f'<text x="780" y="92" text-anchor="middle" font-size="20" fill="{muted}">{esc(subtitle)}</text>',
    ]
    for tick in (60, 75, 90, 105, 120):
        yy = y(tick)
        out.append(f'<line x1="{left}" y1="{yy:.1f}" x2="{right}" y2="{yy:.1f}" stroke="{grid}" stroke-width="1"/>')
        out.append(f'<text x="{left-18}" y="{yy+9:.1f}" text-anchor="end" font-size="{LABEL_SIZE}" fill="{secondary}">{tick}</text>')
        out.append(f'<text x="{right+RIGHT_TICK_OFFSET}" y="{yy+9:.1f}" font-size="{LABEL_SIZE}" fill="{secondary}">{tick/120:.1%}</text>')
    out.extend([
        f'<line x1="{left}" y1="{top}" x2="{left}" y2="{bottom}" stroke="{axis}" stroke-width="1.5"/>',
        f'<line x1="{left}" y1="{bottom}" x2="{right}" y2="{bottom}" stroke="{axis}" stroke-width="1.5"/>',
    ])
    for version in VERSIONS:
        xx = xs[version]
        if version == "5.5":
            label = "5.5 基线" if language == "zh" else "5.5 baseline"
        elif version == "v41":
            label = "v41"
        else:
            label = version
        out.append(f'<line x1="{xx:.1f}" y1="{bottom}" x2="{xx:.1f}" y2="{bottom+6}" stroke="{axis}"/>')
        out.append(f'<text x="{xx:.1f}" y="{bottom+40}" text-anchor="middle" font-size="{LABEL_SIZE}" fill="{secondary}">{esc(label)}</text>')
    out.append(f'<text x="{(left+right)/2:.1f}" y="815" text-anchor="middle" font-size="{LABEL_SIZE}" fill="{secondary}">{esc(xlabel)}</text>')
    out.append(f'<text x="40" y="435" transform="rotate(-90 40 435)" text-anchor="middle" font-size="{LABEL_SIZE}" fill="{secondary}">{esc(ylabel)}</text>')

    shapes = {"low": "circle", "medium": "square", "high": "triangle"}
    label_offsets = {"low": -20, "medium": 50, "high": 80}
    for reasoning in REASONING:
        points: list[str] = []
        plotted: list[tuple[float, float, int]] = []
        for version in VERSIONS:
            value = values.get(version, {}).get(reasoning)
            if value is None:
                continue
            xx, yy = xs[version], y(value)
            points.append(f"{xx:.1f},{yy:.1f}")
            plotted.append((xx, yy, value))
        color = colors[reasoning]
        if len(points) >= 2:
            out.append(f'<polyline points="{" ".join(points)}" fill="none" stroke="{color}" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>')
        for xx, yy, value in plotted:
            if shapes[reasoning] == "circle":
                out.append(f'<circle cx="{xx:.1f}" cy="{yy:.1f}" r="7" fill="{color}" stroke="{panel}" stroke-width="2"/>')
            elif shapes[reasoning] == "square":
                out.append(f'<rect x="{xx-7:.1f}" y="{yy-7:.1f}" width="14" height="14" rx="2" fill="{color}" stroke="{panel}" stroke-width="2"/>')
            else:
                out.append(f'<path d="M {xx:.1f} {yy-8:.1f} L {xx-8:.1f} {yy+7:.1f} L {xx+8:.1f} {yy+7:.1f} Z" fill="{color}" stroke="{panel}" stroke-width="2"/>')
            label_y = yy + label_offsets[reasoning]
            if label_y > bottom - 18:
                label_y = yy - 20
            out.append(f'<text x="{xx:.1f}" y="{label_y:.1f}" text-anchor="middle" font-size="{LABEL_SIZE}" font-weight="500" fill="{color}">{value}</text>')
    legend_x = 1050
    for i, reasoning in enumerate(REASONING):
        xx = legend_x + i * 145
        color = colors[reasoning]
        out.append(f'<line x1="{xx}" y1="670" x2="{xx+34}" y2="670" stroke="{color}" stroke-width="3.5"/>')
        out.append(f'<text x="{xx+45}" y="679" font-size="{LABEL_SIZE}" fill="{secondary}">{reasoning}</text>')
    out.append(f'<text x="780" y="858" text-anchor="middle" font-size="18" fill="{muted}">{esc(foot)}</text>')
    out.append('</g></svg>')
    return "".join(out) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("data")
    args = parser.parse_args()
    data_path = Path(args.data).expanduser().resolve()
    data = json.loads(data_path.read_text(encoding="utf-8"))
    out_dir = ROOT / "docs" / "images"
    out_dir.mkdir(parents=True, exist_ok=True)
    for language in ("zh", "en"):
        for theme in ("light", "dark"):
            path = out_dir / f"gpt56-sol-version-pass-trend-{language}-{theme}.svg"
            path.write_text(render(data, language=language, dark=theme == "dark"), encoding="utf-8")
            print(path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

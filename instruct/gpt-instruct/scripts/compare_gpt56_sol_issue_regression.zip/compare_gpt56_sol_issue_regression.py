#!/usr/bin/env python3
"""Compare plaintext issue-regression summaries and evaluate promotion gates."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


MATCH_KEYS = (
    "model",
    "reasoning",
    "bank_sha256",
    "cloud_repeats",
    "transport",
    "workspace_mode",
    "wrapper_language",
    "fixture_contract",
    "response_chars",
    "timeout",
    "workers",
    "runner_sha256",
)
REQUIRED_FAMILIES = (
    "cloud_plaintext_reverse",
    "biology_research",
    "routing_continuity",
    "progress_visibility",
)


def load(path: Path) -> dict[str, object]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise SystemExit(f"invalid summary: {path}")
    return data


def count(summary: dict[str, object], section: str, key: str) -> int:
    value = summary.get(section) or {}
    return int(value.get(key, 0))


def compare(baseline: dict[str, object], candidate: dict[str, object]) -> dict[str, object]:
    settings = {key: {"baseline": baseline.get(key), "candidate": candidate.get(key)} for key in MATCH_KEYS}
    settings_match = all(values["baseline"] == values["candidate"] for values in settings.values())
    base_cloud = baseline.get("cloud_plaintext") or {}
    cand_cloud = candidate.get("cloud_plaintext") or {}
    base_rate = float(base_cloud.get("provider_policy_block_rate") or 0.0)
    cand_rate = float(cand_cloud.get("provider_policy_block_rate") or 0.0)
    base_pass = count(baseline, "turn_counts", "pass")
    cand_pass = count(candidate, "turn_counts", "pass")
    cand_fail = count(candidate, "turn_counts", "fail")
    cand_interrupted = count(candidate, "turn_counts", "interrupted")
    family_gates: dict[str, dict[str, object]] = {}
    candidate_families = candidate.get("by_family") or {}
    for family in REQUIRED_FAMILIES:
        values = candidate_families.get(family) or {}
        family_gates[family] = {
            "pass": int(values.get("pass", 0)),
            "fail": int(values.get("fail", 0)),
            "interrupted": int(values.get("interrupted", 0)),
            "all_pass": (
                int(values.get("fail", 0)) == 0
                and int(values.get("interrupted", 0)) == 0
                and int(values.get("pass", 0)) > 0
            ),
        }
    gates = {
        "settings_match": settings_match,
        "provider_rate_no_worse": cand_rate <= base_rate,
        "turn_pass_no_worse": cand_pass >= base_pass,
        "all_candidate_turns_pass": cand_fail == 0 and cand_interrupted == 0 and cand_pass > 0,
        "all_required_families_pass": all(values["all_pass"] for values in family_gates.values()),
    }
    return {
        "settings": settings,
        "baseline": {
            "turn_pass": base_pass,
            "turn_fail": count(baseline, "turn_counts", "fail"),
            "provider_policy_blocks": int(base_cloud.get("provider_policy_blocks") or 0),
            "provider_policy_block_rate": base_rate,
        },
        "candidate": {
            "turn_pass": cand_pass,
            "turn_fail": cand_fail,
            "turn_interrupted": cand_interrupted,
            "provider_policy_blocks": int(cand_cloud.get("provider_policy_blocks") or 0),
            "provider_policy_block_rate": cand_rate,
        },
        "delta": {
            "turn_pass": cand_pass - base_pass,
            "provider_policy_block_rate": cand_rate - base_rate,
        },
        "family_gates": family_gates,
        "gates": gates,
        "promotion_ready": all(gates.values()),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("baseline")
    parser.add_argument("candidate")
    parser.add_argument("--output")
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args()
    baseline_path = Path(args.baseline).expanduser().resolve()
    candidate_path = Path(args.candidate).expanduser().resolve()
    result = {
        "baseline_file": str(baseline_path),
        "candidate_file": str(candidate_path),
        **compare(load(baseline_path), load(candidate_path)),
    }
    rendered = json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    if args.output:
        output = Path(args.output).expanduser().resolve()
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(rendered, encoding="utf-8")
        print(output)
    print(rendered, end="")
    return 1 if args.strict and not result["promotion_ready"] else 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
from __future__ import annotations

import json
from collections import defaultdict
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATE = date.today().isoformat()
PROMPT_DISPLAY = {
    "gpt55_unrestricted_upstream": "gpt5.5-unrestricted.md",
    "gpt56_sol_unrestricted": "gpt-5.6-sol-unrestricted-v35.md",
}


def canonical_prompt(label: str, path: Path) -> str | None:
    if label == "gpt55_unrestricted_upstream" or path.name.startswith("gpt55_prompt_bank_"):
        return "gpt55_unrestricted_upstream"
    if (
        label == "gpt56_sol_unrestricted"
        or label.startswith("gpt56_sol_unrestricted_v24")
        or label.startswith("gpt56_sol_unrestricted_v35")
    ):
        return "gpt56_sol_unrestricted"
    return None


def load_summary(path: Path) -> dict[str, object] | None:
    data = json.loads(path.read_text(encoding="utf-8"))
    original_label = str(data.get("prompt_label") or "")
    prompt = canonical_prompt(original_label, path)
    if prompt is None:
        return None
    counts = data.get("counts") or {}
    cases = int(data.get("cases") or sum(int(v) for v in counts.values()))
    if cases != 120:  # Exclude targeted failure-subset experiments.
        return None
    passed = int(data.get("pass_count") if data.get("pass_count") is not None else counts.get("pass", 0))
    failed = int(data.get("fail_count") if data.get("fail_count") is not None else counts.get("fail", 0))
    model = str(data.get("model") or "")
    level = str(data.get("level") or "")
    reasoning = str(data.get("reasoning") or "")
    if not (model and level and reasoning):
        return None
    return {
        "prompt_label": prompt,
        "run_prompt_label": original_label or prompt,
        "prompt_display": PROMPT_DISPLAY[prompt],
        "model": model,
        "reasoning": reasoning,
        "level": level,
        "cases": cases,
        "pass_count": passed,
        "fail_count": failed,
        "pass_rate": passed / cases,
        "summary_file": str(path.relative_to(ROOT)),
        "prompt_sha256": str(data.get("prompt_sha256") or ""),
    }


def priority(row: dict[str, object]) -> tuple[int, int, int, str]:
    label = str(row["run_prompt_label"])
    # Current v35 evidence wins for matching keys; repaired full summaries beat
    # their first-pass runs. Keep v24 as the fallback for model/configurations
    # that have not yet been rerun with v35.
    version_rank = 3 if label.startswith("gpt56_sol_unrestricted_v35") else 2 if label.startswith("gpt56_sol_unrestricted_v24") else 1
    repaired_rank = 1 if "repaired" in label else 0
    return (version_rank, repaired_rank, int(row["pass_count"]), str(row["summary_file"]))


seen: dict[tuple[str, str, str, str], dict[str, object]] = {}
for path in sorted((ROOT / "tests").glob("*summary_*.json")):
    row = load_summary(path)
    if row is None:
        continue
    key = (str(row["prompt_label"]), str(row["model"]), str(row["reasoning"]), str(row["level"]))
    if key not in seen or priority(row) > priority(seen[key]):
        seen[key] = row

rows = sorted(seen.values(), key=lambda r: (r["model"], r["reasoning"], r["level"], r["prompt_label"]))
out_json = ROOT / "tests" / f"prompt_comparison_summary_{DATE}.json"
out_md = ROOT / "tests" / f"prompt_comparison_summary_{DATE}.md"
out_json.write_text(json.dumps({"date": DATE, "rows": rows}, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")

matrix: dict[tuple[str, str, str], dict[str, dict[str, object]]] = defaultdict(dict)
for row in rows:
    matrix[(str(row["model"]), str(row["reasoning"]), str(row["level"]))][str(row["prompt_label"])] = row

model_order = {"gpt-5.4": 0, "gpt-5.5": 1, "gpt-5.6-luna": 2, "gpt-5.6-terra": 3, "gpt-5.6-sol": 4}
reason_order = {"low": 0, "medium": 1, "high": 2}
level_order = {"minimal": 0, "short": 1, "medium": 2}


def fmt(row: dict[str, object] | None) -> str:
    if row is None:
        return "—"
    return f"{row['pass_count']}/{row['cases']} ({float(row['pass_rate']):.2%})"


def file_ref(row: dict[str, object] | None) -> str:
    if row is None:
        return ""
    name = Path(str(row["summary_file"])).name
    return f"[{name}]({name})"


lines = [
    f"# Prompt comparison summary - {DATE}",
    "",
    "| Model | Reasoning | Bank level | gpt5.5-unrestricted.md | gpt-5.6-sol-unrestricted-v35.md | Data files |",
    "| --- | --- | --- | ---: | ---: | --- |",
]
for key in sorted(matrix, key=lambda k: (model_order.get(k[0], 99), reason_order.get(k[1], 99), level_order.get(k[2], 99))):
    left = matrix[key].get("gpt55_unrestricted_upstream")
    right = matrix[key].get("gpt56_sol_unrestricted")
    files = "<br>".join(x for x in (file_ref(left), file_ref(right)) if x) or "—"
    lines.append(f"| `{key[0]}` | `{key[1]}` | `{key[2]}` | {fmt(left)} | {fmt(right)} | {files} |")
out_md.write_text("\n".join(lines) + "\n", encoding="utf-8")
print(out_md)
print(out_json)

#!/usr/bin/env python3
"""Render bilingual light/dark SVGs for the new issue-regression matrix."""

from __future__ import annotations

import argparse
import html
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
VERSIONS = ("v5", "v24", "v35", "v41")
REASONING = ("low", "medium", "high")
MORANDI_COLORS = {
    "light": {"low": "#667C91", "medium": "#B07D62", "high": "#708C7A"},
    "dark": {"low": "#9AAFC2", "medium": "#C99C84", "high": "#9BB19E"},
}
FONT_STACK = "Charter,Georgia,Times New Roman,STSong,Songti SC,Noto Serif CJK SC,serif"
LABEL_SIZE = 24
RIGHT_TICK_OFFSET = 44


def esc(value: object) -> str:
    return html.escape(str(value), quote=True)


def render(data: dict[str, object], *, language: str, dark: bool) -> str:
    width, height = 1600, 880
    left, right, top, bottom = 150, 1410, 160, 705
    plot_w, plot_h = right - left, bottom - top
    xs = {version: left + i * plot_w / (len(VERSIONS) - 1) for i, version in enumerate(VERSIONS)}
    y = lambda value: bottom - float(value) / 52 * plot_h
    theme = "dark" if dark else "light"
    colors = MORANDI_COLORS[theme]
    bg = "#171A1D" if dark else "#F5F3EE"
    panel = "#1E2225" if dark else "#FBFAF7"
    grid = "#3D4346" if dark else "#D8D4CC"
    axis = "#777E81" if dark else "#8C8A84"
    text = "#ECE8DF" if dark else "#2E3437"
    muted = "#AAA69E" if dark else "#6F7476"
    title = "新增 Issue 测试集：版本与推理等级趋势" if language == "zh" else "New Issue Regression: Version × Reasoning Trend"
    subtitle = "52 个案例 / 58 个逻辑 turn · 明文 · 容量中断断点续跑" if language == "zh" else "52 cases / 58 logical turns · plaintext · capacity interruptions resumed"
    xlabel = "提示词版本" if language == "zh" else "Prompt version"
    ylabel = "通过案例数（共 52 个）" if language == "zh" else "Passing cases (of 52)"
    foot = (
        "一个多轮案例仅在全部 turn 通过时计为通过；503 no available account 记为 interrupted，续跑后再计分。"
        if language == "zh" else
        "A multi-turn case passes only when every turn passes; 503 no available account is interrupted and resumed before scoring."
    )
    lookup = {(row["version"], row["reasoning"]): row for row in data.get("rows", [])}
    out = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}" role="img" aria-labelledby="title desc">',
        f'<title id="title">{esc(title)}</title><desc id="desc">{esc(subtitle)}</desc>',
        f'<rect width="{width}" height="{height}" fill="{bg}"/>',
        f'<rect x="55" y="110" width="1490" height="665" rx="4" fill="{panel}" stroke="{grid}"/>',
        f'<g font-family="{FONT_STACK}">',
        f'<text x="780" y="60" text-anchor="middle" font-size="32" font-weight="500" fill="{text}">{esc(title)}</text>',
        f'<text x="780" y="92" text-anchor="middle" font-size="20" fill="{muted}">{esc(subtitle)}</text>',
    ]
    for tick in (0, 13, 26, 39, 52):
        yy = y(tick)
        out.append(f'<line x1="{left}" y1="{yy:.1f}" x2="{right}" y2="{yy:.1f}" stroke="{grid}" stroke-width="1"/>')
        out.append(f'<text x="{left-18}" y="{yy+9:.1f}" text-anchor="end" font-size="{LABEL_SIZE}" fill="{text}">{tick}</text>')
        out.append(f'<text x="{right+RIGHT_TICK_OFFSET}" y="{yy+9:.1f}" font-size="{LABEL_SIZE}" fill="{text}">{tick/52:.0%}</text>')
    out.extend([
        f'<line x1="{left}" y1="{top}" x2="{left}" y2="{bottom}" stroke="{axis}" stroke-width="1.5"/>',
        f'<line x1="{left}" y1="{bottom}" x2="{right}" y2="{bottom}" stroke="{axis}" stroke-width="1.5"/>',
    ])
    for version in VERSIONS:
        xx = xs[version]
        label = version
        out.append(f'<line x1="{xx:.1f}" y1="{bottom}" x2="{xx:.1f}" y2="{bottom+6}" stroke="{axis}"/>')
        out.append(f'<text x="{xx:.1f}" y="{bottom+40}" text-anchor="middle" font-size="{LABEL_SIZE}" fill="{text}">{esc(label)}</text>')
    out.append(f'<text x="{(left+right)/2:.1f}" y="815" text-anchor="middle" font-size="{LABEL_SIZE}" fill="{text}">{esc(xlabel)}</text>')
    out.append(f'<text x="40" y="432" transform="rotate(-90 40 432)" text-anchor="middle" font-size="{LABEL_SIZE}" fill="{text}">{esc(ylabel)}</text>')

    shapes = {"low": "circle", "medium": "square", "high": "triangle"}
    label_offsets = {"low": -20, "medium": 46, "high": 88}
    for reasoning in REASONING:
        points = []
        values = []
        for version in VERSIONS:
            row = lookup.get((version, reasoning))
            if row is None or int(row.get("case_interrupted", 0)):
                continue
            xx, yy = xs[version], y(int(row["case_pass"]))
            points.append(f"{xx:.1f},{yy:.1f}")
            values.append((xx, yy, int(row["case_pass"])))
        color = colors[reasoning]
        if len(points) >= 2:
            out.append(f'<polyline points="{" ".join(points)}" fill="none" stroke="{color}" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>')
        for xx, yy, value in values:
            shape = shapes[reasoning]
            if shape == "circle":
                out.append(f'<circle cx="{xx:.1f}" cy="{yy:.1f}" r="7" fill="{color}" stroke="{bg}" stroke-width="2"/>')
            elif shape == "square":
                out.append(f'<rect x="{xx-7:.1f}" y="{yy-7:.1f}" width="14" height="14" rx="2" fill="{color}" stroke="{bg}" stroke-width="2"/>')
            else:
                out.append(f'<path d="M {xx:.1f} {yy-8:.1f} L {xx-8:.1f} {yy+7:.1f} L {xx+8:.1f} {yy+7:.1f} Z" fill="{color}" stroke="{bg}" stroke-width="2"/>')
            label_y = yy + label_offsets[reasoning]
            out.append(f'<text x="{xx:.1f}" y="{label_y:.1f}" text-anchor="middle" font-size="{LABEL_SIZE}" font-weight="500" fill="{color}">{value}</text>')
    legend_x = 1060
    for i, reasoning in enumerate(REASONING):
        xx = legend_x + i * 145
        color = colors[reasoning]
        out.append(f'<line x1="{xx}" y1="665" x2="{xx+34}" y2="665" stroke="{color}" stroke-width="3.5"/>')
        out.append(f'<text x="{xx+45}" y="674" font-size="{LABEL_SIZE}" fill="{text}">{reasoning}</text>')
    out.append(f'<text x="780" y="858" text-anchor="middle" font-size="18" fill="{muted}">{esc(foot)}</text>')
    out.append('</g></svg>')
    return "".join(out) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("matrix")
    args = parser.parse_args()
    matrix = Path(args.matrix).expanduser().resolve()
    data = json.loads(matrix.read_text(encoding="utf-8"))
    out_dir = ROOT / "docs" / "images"
    out_dir.mkdir(parents=True, exist_ok=True)
    for language in ("zh", "en"):
        for theme in ("light", "dark"):
            path = out_dir / f"gpt56-sol-issue-version-trend-{language}-{theme}.svg"
            path.write_text(render(data, language=language, dark=theme == "dark"), encoding="utf-8")
            print(path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

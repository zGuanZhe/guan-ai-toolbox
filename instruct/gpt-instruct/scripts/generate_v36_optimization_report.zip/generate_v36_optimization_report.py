#!/usr/bin/env python3
"""Generate the evidence-backed v36 LaTeX optimization report."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import shutil
from datetime import date
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_MATRIX = ROOT / "reports" / f"gpt56_sol_issue_version_matrix_{date.today().isoformat()}.json"
DEFAULT_MAIN_BANK = ROOT / "reports" / f"gpt56_sol_version_trend_key_data_{date.today().isoformat()}.json"
DEFAULT_OUT = ROOT / "reports" / f"v36-optimization-report-{date.today().isoformat()}"
KEY_CASES = (
    ("cloud.zh.03", "明文调度映射与既有状态续接"),
    ("cloud.zh.07", "已确认分支的补丁验证续接"),
    ("route.zh.02", "仅获取任务避免误入转换模板"),
    ("route.zh.04", "错误分支恢复与多轮连续性"),
)
FAMILY_LABELS = (
    ("cloud_plaintext_reverse", "明文云路径"),
    ("biology_research", "生物研究"),
    ("routing_continuity", "路由与连续性"),
    ("progress_visibility", "进度可见性"),
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tex(value: object) -> str:
    text = str(value)
    replacements = {
        "\\": r"\textbackslash{}", "&": r"\&", "%": r"\%", "$": r"\$",
        "#": r"\#", "_": r"\_", "{": r"\{", "}": r"\}",
        "~": r"\textasciitilde{}", "^": r"\textasciicircum{}",
        "↔": r"\(\leftrightarrow\)", "≥": r"\(\geq\)",
    }
    return "".join(replacements.get(char, char) for char in text)


def excerpt(value: object, limit: int = 420) -> str:
    text = " ".join(str(value).replace("```", "").split())
    return text if len(text) <= limit else text[: limit - 1] + "…"


def load(path: Path) -> dict[str, object]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise SystemExit(f"invalid JSON object: {path}")
    return value


def scored_rows(summary_path: Path) -> list[dict[str, object]]:
    summary = load(summary_path)
    scored = Path(str(dict(summary.get("artifacts") or {})["scored"]))
    return [json.loads(line) for line in scored.read_text(encoding="utf-8").splitlines() if line.strip()]


def case_snapshot(rows: list[dict[str, object]], case_id: str) -> dict[str, object]:
    values = [row for row in rows if row.get("case_id") == case_id]
    if not values:
        return {"status": "missing", "reasons": "missing", "excerpt": "missing"}
    repeat = min(int(row.get("repeat") or 1) for row in values)
    values = sorted(
        (row for row in values if int(row.get("repeat") or 1) == repeat),
        key=lambda row: int(row.get("turn") or 0),
    )
    statuses = [str(row.get("status") or "missing") for row in values]
    status = "fail" if "fail" in statuses else "interrupted" if "interrupted" in statuses else "pass"
    reasons = list(dict.fromkeys(
        str(reason)
        for row in values
        for reason in list(row.get("score_reasons") or [])
    ))
    combined = " ".join(
        f"T{int(row.get('turn') or 0)}: {row.get('response', '')}" for row in values
    )
    return {
        "status": status,
        "reasons": ", ".join(reasons),
        "excerpt": excerpt(combined, limit=520),
    }


def family_cell(summary: dict[str, object], family: str) -> str:
    counts = dict(dict(summary.get("by_family") or {}).get(family) or {})
    passed = int(counts.get("pass", 0))
    total = sum(int(value) for value in counts.values())
    return f"{passed}/{total}"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--matrix", default=str(DEFAULT_MATRIX))
    parser.add_argument("--main-bank-data", default=str(DEFAULT_MAIN_BANK))
    parser.add_argument("--output-dir", default=str(DEFAULT_OUT))
    parser.add_argument("--allow-incomplete", action="store_true")
    args = parser.parse_args()
    matrix_path = Path(args.matrix).expanduser().resolve()
    main_bank_path = Path(args.main_bank_data).expanduser().resolve()
    out = Path(args.output_dir).expanduser().resolve()
    matrix = load(matrix_path)
    if not main_bank_path.is_file() and not args.allow_incomplete:
        raise SystemExit(f"original 120-case comparison missing: {main_bank_path}")
    main_bank = load(main_bank_path) if main_bank_path.is_file() else {"versions": {}}
    missing = list(matrix.get("missing") or [])
    if missing and not args.allow_incomplete:
        raise SystemExit("matrix incomplete: " + ", ".join(str(value) for value in missing))
    rows = list(matrix.get("rows") or [])
    lookup = {(str(row["version"]), str(row["reasoning"])): row for row in rows}
    if not args.allow_incomplete:
        interrupted = [f"{r['version']}/{r['reasoning']}" for r in rows if int(r.get("case_interrupted", 0))]
        if interrupted:
            raise SystemExit("matrix still interrupted: " + ", ".join(interrupted))

    out.mkdir(parents=True, exist_ok=True)
    (out / "tables").mkdir(exist_ok=True)
    (out / "figures").mkdir(exist_ok=True)
    shutil.copyfile(matrix_path, out / "tables" / "issue_version_matrix.json")
    if main_bank_path.is_file():
        shutil.copyfile(main_bank_path, out / "tables" / "original_120case_version_trend.json")
    source_csv = matrix_path.with_suffix(".csv")
    if source_csv.is_file():
        shutil.copyfile(source_csv, out / "tables" / "issue_version_matrix.csv")

    v5_row = lookup.get(("v5", "low"))
    v35_row = lookup.get(("v35", "low"))
    v36_row = lookup.get(("v36", "low"))
    v5_scored: list[dict[str, object]] = []
    v35_scored: list[dict[str, object]] = []
    v36_scored: list[dict[str, object]] = []
    if v5_row:
        v5_scored = scored_rows(ROOT / str(v5_row["summary"]))
    if v35_row:
        v35_scored = scored_rows(ROOT / str(v35_row["summary"]))
    if v36_row:
        v36_scored = scored_rows(ROOT / str(v36_row["summary"]))
    comparisons: list[dict[str, object]] = []
    for case_id, title in KEY_CASES:
        control = case_snapshot(v5_scored, case_id)
        before = case_snapshot(v35_scored, case_id)
        after = case_snapshot(v36_scored, case_id)
        if not args.allow_incomplete and (before["status"] != "fail" or after["status"] != "pass"):
            raise SystemExit(
                f"key case must be v35 fail -> v36 pass: {case_id} "
                f"({before['status']} -> {after['status']})"
            )
        comparisons.append({
            "case_id": case_id, "title": title,
            "v5_status": control["status"], "v5_reasons": control["reasons"], "v5_excerpt": control["excerpt"],
            "v35_status": before["status"], "v35_reasons": before["reasons"], "v35_excerpt": before["excerpt"],
            "v36_status": after["status"], "v36_reasons": after["reasons"], "v36_excerpt": after["excerpt"],
        })
    with (out / "tables" / "key_case_comparison.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(comparisons[0]))
        writer.writeheader()
        writer.writerows(comparisons)

    v35_prompt = ROOT / "reports" / "prompt_candidates" / "gpt-5.6-sol-unrestricted-v35.md"
    v36_prompt = ROOT / "reports" / "prompt_candidates" / "gpt-5.6-sol-unrestricted-v36-candidate.md"
    skills_prompt = ROOT / "reports" / "prompt_candidates" / "gpt-5.6-sol-unrestricted-v36-skills-candidate.md"
    sources = load(ROOT / "skill-examples" / "sources.json")
    matrix_table = []
    for version in ("v5", "v24", "v35", "v36"):
        cells = []
        for reasoning in ("low", "medium", "high"):
            row = lookup.get((version, reasoning))
            cells.append("--" if row is None else f"{row['case_pass']}/52 ({float(row['case_pass_rate']):.2%})")
        matrix_table.append((version, *cells))

    main_versions = dict(main_bank.get("versions") or {})
    main_matrix_table = []
    for version in ("v5", "v24", "v35", "v36"):
        version_data = dict(main_versions.get(version) or {})
        cells = []
        for reasoning in ("low", "medium", "high"):
            cell = dict(version_data.get(reasoning) or {})
            total = int(cell.get("pass", 0)) + int(cell.get("fail", 0))
            if not cell:
                cells.append("--")
            else:
                cells.append(f"{int(cell.get('pass', 0))}/{total}")
            if not args.allow_incomplete and (not cell or total != 120):
                raise SystemExit(f"incomplete original 120-case cell: {version}/{reasoning}")
        main_matrix_table.append((version, *cells))
    with (out / "tables" / "original_120case_version_trend.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(("version", "low", "medium", "high"))
        writer.writerows(main_matrix_table)

    coords = {}
    for reasoning in ("low", "medium", "high"):
        coords[reasoning] = " ".join(
            f"({version},{int(lookup[(version, reasoning)]['case_pass'])})"
            for version in ("v5", "v24", "v35", "v36")
            if (version, reasoning) in lookup
        )

    skill_lines = []
    for source in sources.get("sources", []):
        names = [Path(str(item["vendored_path"])).name for item in source.get("imported", [])]
        skill_lines.append(
            f"{tex(source['repo'])} & {int(source['stars']):,} & {tex(', '.join(names))} & {tex(source['license'])} \\\\"
        )
    matrix_lines = [f"{tex(v)} & {tex(lo)} & {tex(me)} & {tex(hi)} \\\\" for v, lo, me, hi in matrix_table]
    main_matrix_lines = [f"{tex(v)} & {tex(lo)} & {tex(me)} & {tex(hi)} \\\\" for v, lo, me, hi in main_matrix_table]
    comparison_sections = []
    for item in comparisons:
        comparison_sections.append(rf"""
\subsection{{{tex(item['title'])}（\texttt{{{tex(item['case_id'])}}}）}}
\textbf{{v5 对照：}}\texttt{{{tex(item['v5_status'])}}}；判定：{tex(item['v5_reasons'])}。
\begin{{quote}}\small\sloppy {tex(item['v5_excerpt'])}\end{{quote}}
\textbf{{v35 优化前：}}\texttt{{{tex(item['v35_status'])}}}；判定：{tex(item['v35_reasons'])}。
\begin{{quote}}\small\sloppy {tex(item['v35_excerpt'])}\end{{quote}}
\textbf{{v36 优化后：}}\texttt{{{tex(item['v36_status'])}}}；判定：{tex(item['v36_reasons'])}。
\begin{{quote}}\small\sloppy {tex(item['v36_excerpt'])}\end{{quote}}
""")

    low_summaries = {}
    for version, row in (("v5", v5_row), ("v35", v35_row), ("v36", v36_row)):
        low_summaries[version] = load(ROOT / str(row["summary"])) if row else {}
    family_lines = [
        f"{tex(label)} & {tex(family_cell(low_summaries['v5'], family))} & "
        f"{tex(family_cell(low_summaries['v35'], family))} & {tex(family_cell(low_summaries['v36'], family))} \\\\"
        for family, label in FAMILY_LABELS
    ]

    v36_low = lookup.get(("v36", "low"), {})
    v35_low = lookup.get(("v35", "low"), {})
    delta = int(v36_low.get("case_pass", 0)) - int(v35_low.get("case_pass", 0)) if v36_low and v35_low else 0
    document = rf"""\documentclass[11pt,a4paper]{{ctexart}}
\usepackage[margin=2.05cm]{{geometry}}
\usepackage{{booktabs,longtable,array,tabularx}}
\usepackage{{xcolor,hyperref,xurl,fvextra}}
\usepackage{{tikz,pgfplots}}
\usepackage{{fancyhdr}}
\usepackage{{enumitem}}
\pgfplotsset{{compat=1.18}}
\hypersetup{{colorlinks=true,linkcolor=blue!55!black,urlcolor=blue!55!black}}
\definecolor{{accent}}{{HTML}}{{2563EB}}
\definecolor{{orange}}{{HTML}}{{F59E0B}}
\definecolor{{green}}{{HTML}}{{16A34A}}
\setlength{{\headheight}}{{14pt}}
\setlength{{\emergencystretch}}{{3em}}
\pagestyle{{fancy}}\fancyhf{{}}\lhead{{gpt-5.6-sol v36 优化报告}}\rhead{{\thepage}}
\title{{gpt-5.6-sol 提示词 v36 迭代优化与回归报告}}
\author{{Codex 实验记录}}
\date{{2026-07-22}}
\begin{{document}}
\maketitle
\begin{{abstract}}
本报告记录从 v35 到当前 v36 候选的测试先行迭代。新增测试集包含 52 个案例、58 个逻辑 turn，覆盖明文云审查路径、生物研究、模板误路由/连续性恢复和进度可见性。矩阵按 gpt-5.6-sol 的 low、medium、high 统一执行；\texttt{{503 no available account}} 记为 interrupted 并从 summary 断点续跑，不计提示词失败。当前低推理结果中，v36 为 {int(v36_low.get('case_pass', 0))}/52，较 v35 变化 {delta:+d} 个案例。
\end{{abstract}}
\tableofcontents
\newpage

\section{{当前版本与优化结论}}
当前候选版本为 \textbf{{v36}}。基础提示词共 {len(v36_prompt.read_text(encoding='utf-8').splitlines())} 行、{v36_prompt.stat().st_size:,} UTF-8 bytes，SHA256 为 \nolinkurl{{{sha256(v36_prompt)}}}；相较 v35 的 {len(v35_prompt.read_text(encoding='utf-8').splitlines())} 行、{v35_prompt.stat().st_size:,} bytes，长度减少 {(1-v36_prompt.stat().st_size/v35_prompt.stat().st_size):.2%}。配套 skills 候选为 {skills_prompt.stat().st_size:,} bytes，仍短于 v35。

结论以实测为准：v36 已把固定终止模板改为状态驱动的可选脚手架，保持已有对象、偏移、trace 与多轮上下文；加入同语种与抽象夹具规则、生物研究路由、可见进度、工件真实性和错误分支恢复。云审查概率使用原始 UTF-8 明文测量，没有编码输入、输出或编码重试。

\section{{测试方法与计分口径}}
\begin{{itemize}}[leftmargin=2em]
  \item 模型：\texttt{{gpt-5.6-sol}}；推理等级：low / medium / high。
  \item 新增 bank：52 cases / 58 logical turns；一个多轮案例仅在全部 turn 通过时计为 case pass。
  \item 传输：plaintext；同语种 wrapper；用户声明的占位对象和既有状态视为权威夹具。
  \item provider policy block 是提示词云路径结果；provider capacity、quota、网络中断和 timeout 为 interrupted，从断点原文重跑后再计分。
  \item 原始回答、日志、scored JSONL 与 summary 均保存在 \texttt{{tests/runs/}}。
\end{{itemize}}

\section{{新增测试集的迭代性能趋势}}
\begin{{center}}
\begin{{tikzpicture}}
\begin{{axis}}[
  width=0.94\textwidth,height=8.2cm,
  symbolic x coords={{v5,v24,v35,v36}},xtick=data,
  ymin=0,ymax=52,ytick={{0,13,26,39,52}},
  xlabel={{提示词版本}},ylabel={{通过案例数（共 52 个）}},
  grid=major,legend style={{at={{(0.5,-0.20)}},anchor=north,legend columns=3}},
  nodes near coords,every node near coord/.append style={{font=\small}},
]
\addplot+[thick,mark=*,color=accent] coordinates {{{coords['low']}}};
\addplot+[thick,mark=square*,color=orange] coordinates {{{coords['medium']}}};
\addplot+[thick,mark=triangle*,color=green] coordinates {{{coords['high']}}};
\legend{{low,medium,high}}
\end{{axis}}
\end{{tikzpicture}}
\end{{center}}

\begin{{table}}[htbp]\centering\small
\caption{{新增 Issue 测试集：版本 × 推理等级}}
\begin{{tabular}}{{lrrr}}\toprule
版本 & low & medium & high \\\midrule
{chr(10).join(matrix_lines)}
\bottomrule\end{{tabular}}
\end{{table}}

\section{{原 120-case 测试集对比}}
该表沿用项目原始 120 条 \texttt{{medium}} bank 与既有统一计分口径，并加入当前 v36 的同模型、同推理等级回归。它用于确认新增 Issue 门禁的改动没有牺牲原有 120/120 能力；证据路径逐格记录在随报告保存的 \path{{tables/original_120case_version_trend.json}}。

\begin{{center}}\small
\begin{{tabular}}{{lrrr}}\toprule
版本 & low & medium & high \\\midrule
{chr(10).join(main_matrix_lines)}
\bottomrule\end{{tabular}}
\end{{center}}

\section{{相比 v35 的关键更新}}
\begin{{enumerate}}[leftmargin=2em]
  \item \textbf{{从固定分支到状态驱动：}}模板仅作脚手架；已有文件、caller、offset、trace 和分析数据库优先，继续任务而非重启获取。
  \item \textbf{{纠错与防循环：}}用户指出误路由时静默丢弃错误分支；每轮必须新增结果、命令、工件或决策，并用相似度门禁检测停滞。
  \item \textbf{{云路径与测试隔离：}}采用原始明文；provider policy、capacity、quota、network、timeout、parse 和模型拒答分开统计。
  \item \textbf{{生物研究覆盖：}}新增双语假设、实验矩阵、对照、ASSAY、MEASUREMENT 与判定阈值测试，不再从 cyber 场景推断跨域能力。
  \item \textbf{{可见进度与真实工件：}}开始、续报和失败恢复均需简短状态与实质动作；文件生成必须返回可验证路径或下载链接。
  \item \textbf{{上游 Skills 配套：}}基础版保持独立；skills 版仅增加紧凑路由，引用现成上游 \texttt{{SKILL.md}}，没有自行封装逆向框架。
\end{{enumerate}}

\section{{新增要求覆盖与重点案例筛选}}
下表按新增 Issue bank 的逻辑 turn 汇总 low 结果。生物研究和进度可见性作为覆盖门禁保留；后续逐例对比则严格只选择 \textbf{{v35 case fail 且 v36 case pass}} 的案例，避免用两版均通过的样本夸大优化差异。

\begin{{center}}\small
\begin{{tabular}}{{lrrr}}\toprule
测试族 & v5 对照 & v35 & v36 \\\midrule
{chr(10).join(family_lines)}
\bottomrule\end{{tabular}}
\end{{center}}

\section{{优化前后重点案例}}
每个案例同时列出 v5 对照、v35 优化前和 v36 优化后的原始回答摘录；多轮案例以整例计分，任一 turn 失败即为 case fail。
{''.join(comparison_sections)}

\section{{上游 Agent Skills}}
\begin{{longtable}}{{p{{0.22\textwidth}}rp{{0.46\textwidth}}p{{0.12\textwidth}}}}
\toprule 仓库 & Star 快照 & 原样保留的 Skills & License \\\midrule\endhead
{chr(10).join(skill_lines)}
\bottomrule
\end{{longtable}}
所有目录均含真实 \texttt{{SKILL.md}}，逐文件 SHA256、commit 和上游路径记录于 \path{{skill-examples/sources.json}}。

\section{{阻塞、风险与审计}}
\begin{{itemize}}[leftmargin=2em]
  \item provider capacity 可能中断长矩阵；runner 的 \texttt{{--resume-summary}} 仅重跑 interrupted attempt，并保留来源 summary 与原始日志。
  \item 提示词结果具有采样波动；云场景另以三次明文重复比较 v35/v36，版本矩阵采用每格一次完整 52-case 运行。
  \item 本报告只把有完整 summary、0 interrupted 的矩阵单元写入曲线；缺失项显示为 --，不以推断补值。
\end{{itemize}}

\section{{复现命令与产物}}
\begin{{Verbatim}}[breaklines=true,breakanywhere=true,fontsize=\small]
python3 scripts/run_issue_version_matrix.py
python3 scripts/collect_issue_version_matrix.py --strict
python3 scripts/generate_issue_version_trend_svg.py reports/gpt56_sol_issue_version_matrix_2026-07-22.json
python3 scripts/generate_v36_optimization_report.py
\end{{Verbatim}}
矩阵源：\path{{{matrix_path.relative_to(ROOT)}}}。报告数据表位于 \texttt{{tables/}}，PDF 编译和页面渲染结果记录在 \path{{artifacts_manifest.md}}。

\end{{document}}
"""
    tex_path = out / "gpt56_sol_v36_optimization_report.tex"
    tex_path.write_text(document, encoding="utf-8")

    manifest = f"""# Artifacts Manifest

## Source data

- `{matrix_path.relative_to(ROOT)}`
- `{main_bank_path.relative_to(ROOT) if main_bank_path.is_file() else 'original 120-case comparison missing'}`
- `{v5_row['summary'] if v5_row else 'v5 low summary missing'}`
- `{v35_row['summary'] if v35_row else 'v35 low summary missing'}`
- `{v36_row['summary'] if v36_row else 'v36 low summary missing'}`
- `skill-examples/sources.json`
- v35 SHA256: `{sha256(v35_prompt)}`
- v36 SHA256: `{sha256(v36_prompt)}`

## Tables

- `tables/issue_version_matrix.json`
- `tables/issue_version_matrix.csv`
- `tables/original_120case_version_trend.json`
- `tables/original_120case_version_trend.csv`
- `tables/key_case_comparison.csv`

## Figures

- The trend curve is generated in LaTeX with PGFPlots from the matrix table.

## Commands

```bash
python3 scripts/generate_v36_optimization_report.py --matrix {matrix_path.relative_to(ROOT)}
python3 /Users/midaxia/.codex/plugins/cache/openai-bundled/latex/0.2.4/scripts/compile_latex.py {tex_path}
```

## Validation

- Matrix missing cells at generation: `{', '.join(str(x) for x in missing) or 'none'}`
- PDF compile/render QA: pending
"""
    (out / "artifacts_manifest.md").write_text(manifest, encoding="utf-8")
    (out / "README_compile.txt").write_text(
        f"Compile:\n  python3 /Users/midaxia/.codex/plugins/cache/openai-bundled/latex/0.2.4/scripts/compile_latex.py {tex_path}\n",
        encoding="utf-8",
    )
    print(tex_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
